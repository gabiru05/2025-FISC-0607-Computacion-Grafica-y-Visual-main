export default {
    root: 'src/',
    publicDir: '../static/',
    base: './',
}